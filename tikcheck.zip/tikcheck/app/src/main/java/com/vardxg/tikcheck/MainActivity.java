package com.vardxg.tikcheck;

import android.animation.*;
import android.app.*;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.material.button.*;
import com.google.android.material.textfield.*;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class MainActivity extends AppCompatActivity {
	
	private String username = "";
	private HashMap<String, Object> res = new HashMap<>();
	
	private LinearLayout linear1;
	private LinearLayout linear4;
	private LinearLayout linear3;
	private TextView textview2;
	private TextInputLayout textinputlayout1;
	private MaterialButton materialbutton1;
	private LinearLayout linear2;
	private EditText edittext1;
	private TextView textview1;
	private ImageView taken;
	
	private RequestNetwork request;
	private RequestNetwork.RequestListener _request_request_listener;
	private Intent fxcku = new Intent();
	private AlertDialog.Builder dialog;
	private AlertDialog.Builder eefe;
	private Intent nigger = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear4 = findViewById(R.id.linear4);
		linear3 = findViewById(R.id.linear3);
		textview2 = findViewById(R.id.textview2);
		textinputlayout1 = findViewById(R.id.textinputlayout1);
		materialbutton1 = findViewById(R.id.materialbutton1);
		linear2 = findViewById(R.id.linear2);
		edittext1 = findViewById(R.id.edittext1);
		textview1 = findViewById(R.id.textview1);
		taken = findViewById(R.id.taken);
		request = new RequestNetwork(this);
		dialog = new AlertDialog.Builder(this);
		eefe = new AlertDialog.Builder(this);
		
		materialbutton1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edittext1.getText().toString().isEmpty()) {
					SketchwareUtil.showMessage(getApplicationContext(), "Provide a username!!!");
					taken.setImageResource(R.drawable.ic_clear_black);
				}
				if (edittext1.getText().toString().contains(" @")) {
					SketchwareUtil.showMessage(getApplicationContext(), "Enter username without  @");
					taken.setImageResource(R.drawable.ic_clear_black);
				}
				else {
					try {
						request.startRequestNetwork(RequestNetworkController.GET, "https://www.tiktok.com/oembed?url=https://www.tiktok.com/@".concat(edittext1.getText().toString()), "", _request_request_listener);
					} catch (Exception e) {
						 
					}
				}
			}
		});
		
		_request_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				res = new Gson().fromJson(_response, new TypeToken<HashMap<String, Object>>(){}.getType());
				try {
					if (!_response.contains("embed_product_id")) {
						SketchwareUtil.showMessage(getApplicationContext(), "Not taken, private, or banned");
						taken.setImageResource(R.drawable.ic_clear_black);
					}
					else {
						SketchwareUtil.showMessage(getApplicationContext(), "user taken");
						taken.setImageResource(R.drawable.ic_done_black);
					}
					if (_response.isEmpty()) {
						SketchwareUtil.showMessage(getApplicationContext(), "an error has occured!");
						taken.setImageResource(R.drawable.ic_clear_black);
					}
				} catch (Exception e) {
					 
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		dialog.setTitle("Tikcheck V1.0");
		dialog.setMessage("Thx for use my trash tiktok username check app lol\n\nmake sure to join my telegram channel");
		dialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				fxcku.setData(Uri.parse("https://t.me/vardxg"));
				fxcku.setAction(Intent.ACTION_VIEW);
				startActivity(fxcku);
			}
		});
		dialog.setNeutralButton("No", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				dialog.setMessage("Then fuck u , and support my work nigga");
			}
		});
		dialog.create().show();
		linear3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xFFFFFFFF));
		linear1.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[] {0xFF000000,0xFFF44336}));
		linear4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xFFFFFFFF));
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}